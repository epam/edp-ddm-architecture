#!/usr/bin/env bash

if [ -z "${A_CLUSTER_LOGIN+x}" ];then
  echo "Env variables A_CLUSTER_LOGIN not set."
  exit
fi
if [ -z "${B_CLUSTER_LOGIN+x}" ];then
  echo "Env variables B_CLUSTER_LOGIN not set."
  exit
fi
if [ -z "${BACKUP_NAME+x}" ];then
  echo "Env variables BACKUP_NAME not set."
  exit
fi
if [ -z "${REGISTRY_NAME+x}" ];then
  echo "Env variables REGISTRY_NAME not set."
  exit
fi

cluster_a_login_cmd="${A_CLUSTER_LOGIN}"
cluster_b_login_cmd="${B_CLUSTER_LOGIN}"
backup_name="${BACKUP_NAME}"
registry_name="${REGISTRY_NAME}"
platform="${PLATFORM_ARCH:-linux_amd64}"
large_obc_data="${LARGE_DATA:-false}"
vault_a_key_name="${VAULT_KEY:-autounseal}"
vault_b_key_name="${vault_a_key_name}-${registry_name}-migration"
edp_ns="control-plane"
root_dir=$(pwd)

wget "https://github.com/jonasvinther/medusa/releases/download/v0.5.0/medusa_0.5.0_${platform}.tar.gz" && tar -xvf "medusa_0.5.0_${platform}.tar.gz" && chmod +x medusa

configure_rclone_for_cluster(){
    access_key_aws=$(oc get secret/backup-credentials -n "${edp_ns}" -o jsonpath='{.data.backup-s3-like-storage-access-key-id}' | base64 -d )
    access_secret_key_aws=$(oc get secret/backup-credentials -n "${edp_ns}" -o jsonpath='{.data.backup-s3-like-storage-secret-access-key}' | base64 -d )
    minio_endpoint=$(oc get secret/backup-credentials -n "${edp_ns}" -o jsonpath='{.data.backup-s3-like-storage-url}' | base64 -d)

    echo "
    [${1}]
    type = s3
    env_auth = false
    provider = Minio
    access_key_id = ${access_key_aws}
    secret_access_key = ${access_secret_key_aws}
    endpoint = ${minio_endpoint}
    region = eu-central-1
    location_constraint = EU
    acl = bucket-owner-full-control">> "${root_dir}/rclone.conf"
}

get_bucket_name() {
  oc get secret/backup-credentials -n "${edp_ns}" -o jsonpath='{.data.backup-s3-like-storage-location}' | base64 -d
}
get_dns_wildcard() {
  oc get --namespace=openshift-ingress-operator ingresscontroller/default -o 'jsonpath={.status.domain}'
}
change_dns_wildcard_in_resources() {
  find "${1}" \( -type d -name .git -prune \) -o -type f -print0 | xargs -0 sed -i -e  's/'"${dns_wildcard_a}"'/'"${dns_wildcard_b}"'/g'
}

modify_resource() {
  cp "${1}" "${1}.back"
  cat "${1}.back"| sed ''${2}'' > "${1}"
  rm -rf "${1}.back"
}

create_keycloak_pod() {
  kubectl delete pod -n user-management keycloak-export --ignore-not-found
  keycloak_image=$(oc get pods -l app.kubernetes.io/name=keycloak -n user-management -o jsonpath='{.items[0].spec.containers[0].image}')
  kubectl apply -f - <<EOF
apiVersion: v1
kind: List
items:
  - apiVersion: v1
    kind: Pod
    metadata:
      name: keycloak-export
      namespace: user-management
    spec:
      containers:
        - name: keycloak-export-db
          image: ${keycloak_image}
          command:
            - /opt/keycloak/bin/kc.sh
            - start
            - '--spi-login-protocol-openid-connect-legacy-logout-redirect-uri=true'
            - '--spi-login-protocol-openid-connect-suppress-logout-confirmation-screen=true'
            - '--http-enabled=true'
            - '--http-port=8081'
            - '--hostname-strict=false'
            - '--hostname-strict-https=false'
            - '--log-console-output=json'
            - '--log-console-color=true'
          env:
            - name: KC_HTTP_RELATIVE_PATH
              value: /auth
            - name: KC_USERS
              value: different_files
            - name: KC_DB
              value: postgres
            - name: KC_DB_URL_HOST
              value: keycloak-postgresql
            - name: KC_DB_URL_PORT
              value: '5432'
            - name: KC_DB_URL_DATABASE
              value: keycloak
            - name: KC_DB_USERNAME
              value: postgres
            - name: KC_DB_PASSWORD
              valueFrom:
                secretKeyRef:
                  name: keycloak-postgresql
                  key: password
            - name: KC_METRICS_ENABLED
              value: 'true'
            - name: KC_HEALTH_ENABLED
              value: 'true'
            - name: KC_LOG_LEVEL
              value: INFO
            - name: KC_PROXY
              value: edge
            - name: KEYCLOAK_ADMIN
              valueFrom:
                secretKeyRef:
                  name: keycloak
                  key: username
            - name: KEYCLOAK_ADMIN_PASSWORD
              valueFrom:
                secretKeyRef:
                  name: keycloak
                  key: password
            - name: JAVA_OPTS_APPEND
              value: >-
                -XX:+UseContainerSupport -XX:MaxRAMPercentage=80.0
                -Djava.awt.headless=true
                -Dquarkus.transaction-manager.default-transaction-timeout=3600000
                -Djboss.as.management.blocking.timeout=3600
          volumeMounts:
            - name: realm-volume
              mountPath: /keycloak-export
      serviceAccountName: keycloak
      securityContext:
        runAsNonRoot: true
        runAsGroup: 1000
        runAsUser: 1000
        fsGroup: 1000
      volumes:
        - name: realm-volume
          persistentVolumeClaim:
            claimName: migration-only
EOF

  while [[ $(oc get pod "keycloak-export" -n user-management -o jsonpath='{.status.phase}') != "Running" ]]; do
    sleep 10
    echo "[DEBUG]Pod keycloak-export is not running"
  done

}

#Get current credentials minio credentials from cluster A configuring minio A

eval "${cluster_a_login_cmd}"
configure_rclone_for_cluster "minio-a"
bucket_a_name=$(get_bucket_name)
dns_wildcard_a=$(get_dns_wildcard)

#export vault transit key
export VAULT_ADDR=$(oc get secret -n ${edp_ns} vault-root-access-token -o jsonpath='{.data.vaultUrl}'| base64 -d)
export VAULT_TOKEN=$(oc get secret -n ${edp_ns} vault-root-access-token -o jsonpath='{.data.vault-access-token}' | base64 -d)
vault write transit/keys/${vault_a_key_name}/config allow_plaintext_backup=true exportable=true
vault read transit/backup/${vault_a_key_name} | sed '1,2d' | awk '{print $2}' > autounseal-a.txt
unset VAULT_ADDR && unset VAULT_TOKEN

#export user-management vault data
export VAULT_ADDR=https://$(oc get routes -n user-management hashicorp-vault -o jsonpath='{.spec.host}')
export VAULT_TOKEN=$(oc get secret -n user-management vault-root-token -o jsonpath='{.data.VAULT_ROOT_TOKEN}' | base64 -d)

./medusa export "registry-kv/registry/${registry_name}" -o registry-kv.yaml
./medusa export "platform-integration/${registry_name}" -o platform-integration.yaml 2> errors
./medusa export "custom-dns-names/${registry_name}" -o custom-dns-names.yaml 2> errors
unset VAULT_TOKEN && unset VAULT_ADDR

#Get secret nexus data
nexusNamespacedSecretRawData=$(oc get secret -n "${registry_name}" nexus-docker-registry-namespaced -o jsonpath='{.data.\.dockerconfigjson}' | base64 -d )

###Get files from Keycloak POD

kubectl apply -f - <<EOF
kind: PersistentVolumeClaim
apiVersion: v1
metadata:
  name: migration-only
  namespace: user-management
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 1Gi
  storageClassName: ocs-storagecluster-ceph-rbd
  volumeMode: Filesystem
EOF

create_keycloak_pod

sleep 60

for realmName in "${registry_name}-officer-portal" "${registry_name}-citizen-portal" "${registry_name}-external-system";do
   oc exec -n user-management -it "keycloak-export" -- bash -c './opt/keycloak/bin/kc.sh export --realm '${realmName}' --users different_files --users-per-file 500 --dir /keycloak-export'
done

oc delete pod -n user-management keycloak-export --ignore-not-found

kubectl apply -f - <<EOF
apiVersion: v1
kind: Pod
metadata:
  name: read-migration
  namespace: user-management
  labels:
    app: httpd
spec:
  securityContext:
    runAsNonRoot: true
    seccompProfile:
      type: RuntimeDefault
  containers:
    - name: volume
      image: 'busybox'
      command: ["sleep", "3600"]
      volumeMounts:
      - name: realms
        mountPath: /tmp/keycloak-export
  volumes:
  - name: realms
    persistentVolumeClaim:
     claimName: migration-only

EOF

while [[ $(oc get pod "read-migration" -n user-management -o jsonpath='{.status.phase}') != "Running" ]]; do
  sleep 10
  echo "Pod read-migration is not running"
done

oc -n user-management cp read-migration:/tmp/keycloak-export keycloak-export
oc delete pod -n user-management read-migration --ignore-not-found
oc delete pvc -n user-management migration-only

AvaultPlatformUrlFromSecret=$(oc get secret -n control-plane "vault-root-access-token" -o jsonpath="{.data.vaultUrl}" | base64 -d)
AvaultPlatformUrl="${AvaultPlatformUrlFromSecret/\/\//\\/\\/}"
AbucketMinio=$(oc get secret -n control-plane backup-credentials -o jsonpath='{.data.backup-s3-like-storage-location}' | base64 -d)

#Get current minio credential from cluster B configuring minio B
eval "${cluster_b_login_cmd}"
configure_rclone_for_cluster "minio-b"
bucket_b_name=$(get_bucket_name)
dns_wildcard_b=$(get_dns_wildcard)
BbucketMinio=$(oc get secret -n control-plane backup-credentials -o jsonpath='{.data.backup-s3-like-storage-location}' | base64 -d)

#import transit key
export VAULT_ADDR=$(oc get secret -n ${edp_ns} vault-root-access-token -o jsonpath='{.data.vaultUrl}'| base64 -d)
export VAULT_TOKEN=$(oc get secret -n ${edp_ns} vault-root-access-token -o jsonpath='{.data.vault-access-token}' | base64 -d)
vault write transit/restore/${vault_b_key_name} backup=@autounseal-a.txt 2> errors
rm -rf autounseal-a.txt
unset VAULT_ADDR && unset VAULT_TOKEN

#import user-management data
export VAULT_ADDR=https://$(oc get routes -n user-management hashicorp-vault -o jsonpath='{.spec.host}')
export VAULT_TOKEN=$(oc get secret -n user-management vault-root-token -o jsonpath='{.data.VAULT_ROOT_TOKEN}' | base64 -d)

./medusa import  registry-kv registry-kv.yaml
./medusa import  platform-integration platform-integration.yaml 2> errors
./medusa import  custom-dns-names custom-dns-names.yaml 2> errors

rm -rf medusa LICENSE README.md medusa* registry-kv.yaml platform-integration.yaml custom-dns-names.yaml

unset VAULT_TOKEN && unset VAULT_ADDR


kubectl apply -f - <<EOF
apiVersion: v1.edp.epam.com/v1
kind: KeycloakClient
metadata:
  name: ${registry_name}-admin
  namespace: user-management
  labels:
    relatedNamespace: ${registry_name}
spec:
  clientId: ${registry_name}-admin
  public: false
  directAccess: false
  reconciliationStrategy: addOnly
  advancedProtocolMappers: false
  serviceAccount:
    attributes: null
    clientRoles:
      - clientId: openshift-realm
        roles:
          - manage-clients
      - clientId: id-gov-ua-realm
        roles:
          - manage-clients
    enabled: true
    realmRoles:
      - create-realm
  webUrl: ''
  targetRealm: master
EOF
# Copy to local archive
rm -rf tmp-archive && mkdir tmp-archive
cd tmp-archive || exit
rclone --config "${root_dir}/rclone.conf" copy "minio-a:${bucket_a_name}/openshift-backups/backups/${backup_name}"  "${backup_name}"

# Unzip
cd ${backup_name} && mkdir ${backup_name}-unziped
modify_resource "openshift-resources/postgrescluster/analytical.yaml" 's/'${AbucketMinio}'/'${BbucketMinio}'/g'
modify_resource "openshift-resources/postgrescluster/operational.yaml" 's/'${AbucketMinio}'/'${BbucketMinio}'/g'

tar -xf ${backup_name}.tar.gz -C ${backup_name}-unziped
for folder in "${backup_name}-unziped/resources" "openshift-resources";do
  change_dns_wildcard_in_resources "${folder}"
done
rm -rf ${backup_name}.tar.gz
cd ${backup_name}-unziped || exit
vaultPlatformSecret=$(oc get secret -n control-plane "vault-root-access-token" -o jsonpath="{.data.vault-access-token}")
vaultCentralSecret=$(oc get secret -n user-management "vault-root-token" -o jsonpath="{.data.VAULT_ROOT_TOKEN}")
vaultPlatformUrlFromSecret=$(oc get secret -n control-plane "vault-root-access-token" -o jsonpath="{.data.vaultUrl}" | base64 -d)
vaultPlatformUrl="${vaultPlatformUrlFromSecret/\/\//\\/\\/}"

minioUrlFromSecret=$(oc get secret backup-credentials -n control-plane -o jsonpath='{.data.backup-s3-like-storage-url}' | base64 -d)
minioPlatformPassword=$(oc get secret backup-credentials -n control-plane -o jsonpath='{.data.backup-s3-like-storage-secret-access-key}' | base64 -d)
minioPlatformUrl="${minioUrlFromSecret/\/\//\\/\\/}"
s3ConfData=$(printf "[global]\nrepo1-s3-key=minio\nrepo1-s3-key-secret=${minioPlatformPassword}" | base64 -w0)

nexusNamespacedSecretData=$(echo "${nexusNamespacedSecretRawData}" | sed 's/'${dns_wildcard_a}'/'${dns_wildcard_b}'/g' | base64 -w0)
echo "${nexusNamespacedSecretRawData}" | sed 's/'${dns_wildcard_a}'/'${dns_wildcard_b}'/g'
modify_resource "resources/configmaps/namespaces/${registry_name}/hashicorp-vault-config.json" 's/'${AvaultPlatformUrl}'/'${vaultPlatformUrl}'/g'
modify_resource "resources/configmaps/namespaces/${registry_name}/hashicorp-vault-config.json" 's/'${vault_a_key_name}'/'${vault_b_key_name}'/g'
modify_resource "resources/secrets/namespaces/${registry_name}/central-vault-token.json" 's/token":".*"},"kind/token":"'${vaultCentralSecret}'"},"kind/g'
modify_resource "resources/secrets/namespaces/${registry_name}/platform-vault-token.json" 's/token":".*"},"kind/token":"'${vaultPlatformSecret}'"},"kind/g'
modify_resource "resources/secrets/namespaces/${registry_name}/s3-conf.json" 's/s3.conf":".*"},"kind/s3.conf":"'${s3ConfData}'"},"kind/g'
modify_resource "resources/secrets/namespaces/${registry_name}/nexus-docker-registry-namespaced.json" 's/dockerconfigjson":".*"},"kind/dockerconfigjson":"'$nexusNamespacedSecretData'"},"kind/g'

#Modify keycloak secret.
while [[ ! $(oc get secret -n user-management "keycloak-client-${registry_name}-admin-secret"  --ignore-not-found) ]];do
  echo "waiting for the secret"
done

for configmapPatern in "registry-kafka-api-master" "registry-soap-api-master" "registry-rest-api-master" "registry-model-master";do
  rm -rf resources/configmaps/namespaces/${registry_name}/${configmapPatern}*
done

keycloakSecret=$(oc get secret -n user-management "keycloak-client-${registry_name}-admin-secret" -o jsonpath="{.data.clientSecret}")
modify_resource "resources/secrets/namespaces/${registry_name}/keycloak.json" 's/password":".*","user/password":"'${keycloakSecret}'","user/g'

tar -zcf ${backup_name}.tar.gz resources metadata
mv ${backup_name}.tar.gz ..
cd ..
rm -rf ${backup_name}-unziped
cd ..


## Copy data to cluster B
rclone --config "${root_dir}/rclone.conf" copy "${backup_name}" "minio-b:${bucket_b_name}/openshift-backups/backups/${backup_name}" --progress
rclone --config "${root_dir}/rclone.conf" copy "minio-a:${bucket_a_name}/openshift-backups/restic/${registry_name}" "minio-b:${bucket_b_name}/openshift-backups/restic/${registry_name}" --progress

if [ ${large_obc_data} == "false" ];then
  rclone copy --config "${root_dir}/rclone.conf" -M "minio-a:${bucket_a_name}/obc-backups/${registry_name}" "minio-b:${bucket_b_name}/obc-backups/${registry_name}" --progress
else
  echo "ENV variables LARGE_DATA set to true. Please run copy below script and execute it separately from script. Copy and past to terminal and press Enter"
  echo "rclone copy --config "${root_dir}/rclone.conf" -M minio-a:${bucket_a_name}/obc-backups/${registry_name} minio-b:${bucket_b_name}/obc-backups/${registry_name} --progress"
fi

rm -rf "${root_dir}/rclone.conf"