#!/usr/bin/env bash
trap cleanup EXIT
#VERSION,WORKSPACE
LOG_LEVEL="${LOG_LEVEL:-info}"
if [[ "${LOG_LEVEL}" == "debug" ]]; then
    set -x
fi


if [ -z "${SRC_CLUSTER_LOGIN+x}" ];then
  echo "Env variables SRC_CLUSTER_LOGIN not set."
  exit
fi
if [ -z "${DEST_CLUSTER_LOGIN+x}" ];then
  echo "Env variables DEST_CLUSTER_LOGIN not set."
  exit
fi
if [ -z "${BACKUP_NAME+x}" ];then
  echo "Env variables BACKUP_NAME not set."
  exit
fi
if [ -z "${REGISTRY_NAME+x}" ];then
  echo "Env variables REGISTRY_NAME not set."
  exit
fi



MINIO_SRC_SSE="${MINIO_SRC_SSE:-false}"
MINIO_DEST_SSE="${MINIO_DEST_SSR:-false}"
CONTROL_PLANE_NAMESPACE="control-plane"
USER_MANAGEMENT_NAMESPACE="user-management"
MINIO_SRC_NAME="src-minio"
MINIO_DEST_NAME="dest-minio"
MINIO_SETTINGS_SECRET="backup-credentials"
PLATFORM_VAULT_SETTINGS_SECRET="vault-root-access-token"
KEYCLOAK_EXPORT_FOLDER_NAME="keycloak-export-${REGISTRY_NAME}"
OSD_STORAGE_CLASS_NAME="ocs-storagecluster-ceph-rbd"
VAULT_AUTOUNSEAL_MIGRATION_FILE="autonseal-${REGISTRY_NAME}"
VAULT_PLATFORM_INTEGRATION_DATA_PATH="platform-integration"
VAULT_PLATFORM_INTEGRATION_DATA_FILE="${VAULT_PLATFORM_INTEGRATION_DATA_PATH}-${REGISTRY_NAME}"
VAULT_CUSTOM_DNS_PATH="custom-dns"
VAULT_CUSTOM_DNS_DATA_FILE="${VAULT_CUSTOM_DNS_PATH}-${REGISTRY_NAME}"
VAULT_REGISTRY_DATA_PATH="registry-kv"
VAULT_REGISTRY_DATA_FILE="${VAULT_REGISTRY_DATA_PATH}-${REGISTRY_NAME}"
VAULT_UM_ROUTE_NAME="hashicorp-vault"
VAULT_UM_SECRET_NAME="vault-root-token"
NEXUS_NAMESPACED_SECRET="${NEXUS_NAMESPACED_SECRET:-nexus-docker-registry-namespaced}"
BACKUP_DIR_PATH="migration-${REGISTRY_NAME}"
IS_REGISTRY_KV_EXIST_IN_VAULT="false"
IS_PLATFORM_INTEGRATION_EXIST_IN_VAULT="false"
IS_CUSTOM_DNS_EXIST_IN_VAULT="false"

VAULT_SRC_KEY_NAME="${VAULT_KEY:-autounseal}"
VAULT_DEST_KEY_NAME="${VAULT_SRC_KEY_NAME}-${REGISTRY_NAME}-migration"
CURRENT_DIR="$(pwd)"
RCLONE_CONFIG="${CURRENT_DIR}/rclone.conf"


declare MINIO_SRC_ENDPOINT MINIO_DEST_ENDPOINT MINIO_SRC_ACCESS_KEY_ID MINIO_SRC_SECRET_ACCESS_KEY \
        MINIO_DEST_ACCESS_KEY_ID MINIO_DEST_SECRET_ACCESS_KEY MINIO_SRC_BUCKET_NAME MINIO_DEST_BUCKET_NAME \
        SRC_CLUSTER_DNS_WILDCARD SRC_NAMESPACED_DOCKERCONFIG_RAW VAULT_SRC_PLATFORM_URL DEST_CLUSTER_DNS_WILDCARD \
        VAULT_DEST_PLATFORM_REPL_ENDPOINT IS_REGISTRY_KV_EXIST_IN_VAULT IS_CUSTOM_DNS_EXIST_IN_VAULT \
        IS_PLATFORM_INTEGRATION_EXIST_IN_VAULT MIGRATE_BUCKETS_ONLY MINIO_SRC_ENDPOINT_OVERWRITE MINIO_DEST_ENDPOINT_OVERWRITE \
        BUCKET_MIGRATION

readonly MINIO_SRC_SSE MINIO_DEST_SSE VAULT_SRC_KEY_NAME VAULT_DEST_KEY_NAME CURRENT_DIR \
         MINIO_SRC_NAME MINIO_DEST_NAME MINIO_SETTINGS_SECRET PLATFORM_VAULT_SETTINGS_SECRET USER_MANAGEMENT_NAMESPACE \
         CONTROL_PLANE_NAMESPACE REGISTRY_NAME BACKUP_NAME DEST_CLUSTER_LOGIN SRC_CLUSTER_LOGIN KEYCLOAK_EXPORT_FOLDER_NAME \
         OSD_STORAGE_CLASS_NAME VAULT_AUTOUNSEAL_MIGRATION_FILE VAULT_UM_ROUTE_NAME VAULT_UM_SECRET_NAME \
         VAULT_PLATFORM_INTEGRATION_DATA_FILE VAULT_CUSTOM_DNS_DATA_FILE VAULT_REGISTRY_DATA_FILE BACKUP_DIR_PATH

function prerequisites() {
    local platform medusa_download_url
    platform="${PLATFORM_ARCH:-linux_amd64}"
    medusa_download_url="https://github.com/jonasvinther/medusa/releases/download/v0.5.0/medusa_0.5.0_${platform}.tar.gz"
    wget -q --show-progress "${medusa_download_url}"
    tar -xf "medusa_0.5.0_${platform}.tar.gz"
    chmod +x medusa
}

function check_vault_path_exists() {
    local vault_addr vault_token vault_path response_code
    vault_addr="${1}"  # Vault server address (e.g., https://127.0.0.1:8200)
    vault_token="${2}"  # Vault Token for authentication
    vault_path="${3}"   # Vault path to check (e.g., secret/metadata/my-path)

    # Make the cURL request with the LIST endpoint for KV2 metadata
    response_code=$(curl --silent --header "X-Vault-Token: ${vault_token}" \
                          --request LIST \
                          --write-out "%{http_code}" \
                          --output /dev/null \
                          "${vault_addr}/v1/${vault_path}")

    # Check the HTTP status code
    if [[ "${response_code}" -eq 200 ]]; then
        echo "Path '${vault_path}' exists in Vault (KV2)."
        return 0
    elif [[ "${response_code}" -eq 404 ]]; then
        echo "Path '${vault_path}' does not exist in Vault (KV2)."
        return 1
    else
        echo "An error occurred while checking path '${vault_path}' in Vault. HTTP Status: ${response_code}"
        return 2
    fi
}

function cleanup() {
   rm -rf "${VAULT_AUTOUNSEAL_MIGRATION_FILE}" \
          "${VAULT_CUSTOM_DNS_DATA_FILE}" \
          "${VAULT_PLATFORM_INTEGRATION_DATA_FILE}" \
          "${VAULT_REGISTRY_DATA_FILE}" \
          "${BACKUP_DIR_PATH}" \
          "LICENSE" \
          "README.md" \
          medusa* \
          "${RCLONE_CONFIG}"

}

function get_secret_attribute() {
  local secret_name namespace jsonpath
  secret_name="${1}"
  namespace="${2}"
  jsonpath="${3}"
  oc get secret -n "${namespace}" "${secret_name}" -o jsonpath='{'"${jsonpath}"'}'| base64 -d
}

function check_connection() {
  local url

  url="${1}"
  # Timeout settings
  SECONDS=0
  TIMEOUT=60

  echo "Waiting for connection to $url..."

  while [[ $SECONDS -lt $TIMEOUT ]]; do
    # Check if we can connect to the URL
    curl --silent --head --connect-timeout 5 "$url" > /dev/null
    if [[ $? -eq 0 ]]; then
      echo "Successfully connected to $url"
      return 0
    fi
    sleep 5
  done

  echo "Failed to connect to $url within $TIMEOUT seconds."
  exit 1
}

configure_rclone_for_cluster(){
    access_key_aws=$(get_secret_attribute "${MINIO_SETTINGS_SECRET}" "${CONTROL_PLANE_NAMESPACE}"  ".data.backup-s3-like-storage-access-key-id")
    access_secret_key_aws=$(get_secret_attribute "${MINIO_SETTINGS_SECRET}" "${CONTROL_PLANE_NAMESPACE}"  ".data.backup-s3-like-storage-secret-access-key")
    minio_endpoint=$(get_secret_attribute "${MINIO_SETTINGS_SECRET}" "${CONTROL_PLANE_NAMESPACE}"   ".data.backup-s3-like-storage-url")
    check_connection "${minio_endpoint}"


    echo "
    [${1}]
    type = s3
    env_auth = false
    provider = Minio
    access_key_id = ${access_key_aws}
    secret_access_key = ${access_secret_key_aws}
    endpoint = ${minio_endpoint}
    region = eu-central-1
    location_constraint = EU
    acl = bucket-owner-full-control">> "${RCLONE_CONFIG}"

    if [[ "${MINIO_SRC_SSE}" == "true" || "${MINIO_DEST_SSE}" == "true" ]]; then
        echo "server_side_encryption = aws:kms" >> "${RCLONE_CONFIG}"
    fi
}

get_dns_wildcard() {
  oc get --namespace=openshift-ingress-operator ingresscontroller/default -o 'jsonpath={.status.domain}'
}

change_dns_wildcard_in_resources() {
  find "${1}" \( -type d -name .git -prune \) -o -type f -print0 | xargs -0 sed -i -e  's/'"${SRC_CLUSTER_DNS_WILDCARD}"'/'"${DEST_CLUSTER_DNS_WILDCARD}"'/g'
}

modify_resource() {
  cp "${1}" "${1}.back"
  cat "${1}.back"| sed ''${2}'' > "${1}"
  rm -rf "${1}.back"
}

create_keycloak_pod() {
  local pod_name keycloak_label pvc_name
  pod_name="${1}"
  pvc_name="${2}"
  keycloak_label="app.kubernetes.io/name=keycloak"
  kubectl delete pod -n "${USER_MANAGEMENT_NAMESPACE}" "${pod_name}" --ignore-not-found
  keycloak_image=$(oc get pods -l "${keycloak_label}" -n ${USER_MANAGEMENT_NAMESPACE} -o jsonpath='{.items[0].spec.containers[0].image}')
  kubectl apply -f - <<EOF
apiVersion: v1
kind: List
items:
  - apiVersion: v1
    kind: Pod
    metadata:
      name: "${pod_name}"
      namespace: ${USER_MANAGEMENT_NAMESPACE}
    spec:
      containers:
        - name: keycloak-export-db
          image: ${keycloak_image}
          command:
            - /opt/keycloak/bin/kc.sh
            - start
            - '--spi-login-protocol-openid-connect-legacy-logout-redirect-uri=true'
            - '--spi-login-protocol-openid-connect-suppress-logout-confirmation-screen=true'
            - '--http-enabled=true'
            - '--http-port=8081'
            - '--hostname-strict=false'
            - '--hostname-strict-https=false'
            - '--log-console-output=json'
            - '--log-console-color=true'
          env:
            - name: KC_HTTP_RELATIVE_PATH
              value: /auth
            - name: KC_USERS
              value: different_files
            - name: KC_DB
              value: postgres
            - name: KC_DB_URL_HOST
              value: keycloak-postgresql
            - name: KC_DB_URL_PORT
              value: '5432'
            - name: KC_DB_URL_DATABASE
              value: keycloak
            - name: KC_DB_USERNAME
              value: postgres
            - name: KC_DB_PASSWORD
              valueFrom:
                secretKeyRef:
                  name: keycloak-postgresql
                  key: password
            - name: KC_METRICS_ENABLED
              value: 'true'
            - name: KC_HEALTH_ENABLED
              value: 'true'
            - name: KC_LOG_LEVEL
              value: INFO
            - name: KC_PROXY
              value: edge
            - name: KEYCLOAK_ADMIN
              valueFrom:
                secretKeyRef:
                  name: keycloak
                  key: username
            - name: KEYCLOAK_ADMIN_PASSWORD
              valueFrom:
                secretKeyRef:
                  name: keycloak
                  key: password
            - name: JAVA_OPTS_APPEND
              value: >-
                -XX:+UseContainerSupport -XX:MaxRAMPercentage=80.0
                -Djava.awt.headless=true
                -Dquarkus.transaction-manager.default-transaction-timeout=3600000
                -Djboss.as.management.blocking.timeout=3600
          volumeMounts:
            - name: realm-volume
              mountPath: /keycloak-export
      serviceAccountName: keycloak
      securityContext:
        runAsNonRoot: true
        runAsGroup: 1000
        runAsUser: 1000
        fsGroup: 1000
      volumes:
        - name: realm-volume
          persistentVolumeClaim:
            claimName: ${pvc_name}
EOF

  while [[ $(oc get pod "${pod_name}" -n ${USER_MANAGEMENT_NAMESPACE} -o jsonpath='{.status.phase}') != "Running" ]]; do
    sleep 10
    echo "[DEBUG]Pod ${pod_name} is not running"
  done

}

function export_keycloak_realms() {
  local migration_pod_name pvc_name timeout volume_pod_name
  pvc_name="keycloak-export-${REGISTRY_NAME}"
  migration_pod_name="keycloak-export-${REGISTRY_NAME}"
  volume_pod_name="file-transfer-${REGISTRY_NAME}"
  timeout=60
  kubectl apply -f - <<EOF
kind: PersistentVolumeClaim
apiVersion: v1
metadata:
  name: ${pvc_name}
  namespace: ${USER_MANAGEMENT_NAMESPACE}
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 1Gi
  storageClassName: ${OSD_STORAGE_CLASS_NAME}
  volumeMode: Filesystem
EOF

  create_keycloak_pod "${migration_pod_name}" "${pvc_name}"

  sleep $timeout

  for realmName in "${REGISTRY_NAME}-officer-portal" "${REGISTRY_NAME}-citizen-portal" "${REGISTRY_NAME}-external-system";do
     oc exec -n "${USER_MANAGEMENT_NAMESPACE}" -it "${migration_pod_name}" -- bash -c './opt/keycloak/bin/kc.sh export --realm '${realmName}' --users different_files --users-per-file 500 --dir /keycloak-export'
  done

  oc delete pod -n "${USER_MANAGEMENT_NAMESPACE}" "${migration_pod_name}" --ignore-not-found

  kubectl apply -f - <<EOF
apiVersion: v1
kind: Pod
metadata:
  name: ${volume_pod_name}
  namespace: ${USER_MANAGEMENT_NAMESPACE}
  labels:
    app: httpd
spec:
  securityContext:
    runAsNonRoot: true
    seccompProfile:
      type: RuntimeDefault
  containers:
    - name: volume
      image: 'busybox'
      command: ["sleep", "3600"]
      volumeMounts:
      - name: realms
        mountPath: /tmp/keycloak-export
  volumes:
  - name: realms
    persistentVolumeClaim:
     claimName: ${pvc_name}

EOF

  while [[ $(oc get pod "${volume_pod_name}" -n ${USER_MANAGEMENT_NAMESPACE} -o jsonpath='{.status.phase}') != "Running" ]]; do
    sleep 10
    echo "Pod ${volume_pod_name} is not running"
  done

  oc -n "${USER_MANAGEMENT_NAMESPACE}" cp "${volume_pod_name}:/tmp/keycloak-export" "${KEYCLOAK_EXPORT_FOLDER_NAME}"
  oc delete pod -n ${USER_MANAGEMENT_NAMESPACE} "${volume_pod_name}" --ignore-not-found
  oc delete pvc -n ${USER_MANAGEMENT_NAMESPACE} "${pvc_name}" --ignore-not-found

}

function export_vault_autounseal_key() {
        export VAULT_ADDR=$(get_secret_attribute "${PLATFORM_VAULT_SETTINGS_SECRET}" "${CONTROL_PLANE_NAMESPACE}" ".data.vaultUrl")
        export VAULT_TOKEN=$(get_secret_attribute "${PLATFORM_VAULT_SETTINGS_SECRET}" "${CONTROL_PLANE_NAMESPACE}" ".data.vault-access-token")

        check_connection "${VAULT_ADDR}"

        vault write "transit/keys/${VAULT_SRC_KEY_NAME}/config" allow_plaintext_backup=true exportable=true
        vault read "transit/backup/${VAULT_SRC_KEY_NAME}" | sed '1,2d' | awk '{print $2}' > "${VAULT_AUTOUNSEAL_MIGRATION_FILE}"
        unset VAULT_ADDR && unset VAULT_TOKEN
}

function import_vault_autounseal_key() {
    #import transit key
    export VAULT_ADDR=$(oc get secret -n ${CONTROL_PLANE_NAMESPACE} ${PLATFORM_VAULT_SETTINGS_SECRET} -o jsonpath='{.data.vaultUrl}'| base64 -d)
    check_connection "${VAULT_ADDR}"
    export VAULT_TOKEN=$(oc get secret -n ${CONTROL_PLANE_NAMESPACE} ${PLATFORM_VAULT_SETTINGS_SECRET} -o jsonpath='{.data.vault-access-token}' | base64 -d)
    vault write "transit/restore/${VAULT_DEST_KEY_NAME}" backup="@${VAULT_AUTOUNSEAL_MIGRATION_FILE}"
    unset VAULT_ADDR && unset VAULT_TOKEN
}

function export_registry_configuration_secrets() {
        export VAULT_ADDR=https://$(oc get routes -n ${USER_MANAGEMENT_NAMESPACE} ${VAULT_UM_ROUTE_NAME} \
                                    -o jsonpath='{.spec.host}')
        check_connection "${VAULT_ADDR}"
        export VAULT_TOKEN=$(oc get secret -n ${USER_MANAGEMENT_NAMESPACE} ${VAULT_UM_SECRET_NAME} \
                             -o jsonpath='{.data.VAULT_ROOT_TOKEN}' | base64 -d)
        check_vault_path_exists "${VAULT_ADDR}" "${VAULT_TOKEN}" "${VAULT_REGISTRY_DATA_PATH}/metadata/registry/${REGISTRY_NAME}"

        if [[ $? -eq 0 ]]; then
          IS_REGISTRY_KV_EXIST_IN_VAULT="true"
        fi
        check_vault_path_exists "${VAULT_ADDR}" "${VAULT_TOKEN}" "${VAULT_CUSTOM_DNS_PATH}/metadata/${REGISTRY_NAME}"
        if [[ $? -eq 0 ]]; then
          IS_CUSTOM_DNS_EXIST_IN_VAULT="true"
        fi
        check_vault_path_exists "${VAULT_ADDR}" "${VAULT_TOKEN}" "${VAULT_PLATFORM_INTEGRATION_DATA_PATH}/metadata/${REGISTRY_NAME}"
        if [[ $? -eq 0 ]]; then
          IS_PLATFORM_INTEGRATION_EXIST_IN_VAULT="true"
        fi
        
        if [[ "${IS_REGISTRY_KV_EXIST_IN_VAULT}" == "true" ]];then
          ./medusa export "${VAULT_REGISTRY_DATA_PATH}/registry/${REGISTRY_NAME}" -o "${VAULT_REGISTRY_DATA_FILE}"
        fi
        if [[ "${IS_PLATFORM_INTEGRATION_EXIST_IN_VAULT}" == "true" ]];then
          ./medusa export "${VAULT_PLATFORM_INTEGRATION_DATA_PATH}/${REGISTRY_NAME}" -o "${VAULT_PLATFORM_INTEGRATION_DATA_FILE}"
        fi
        if [[ "${IS_CUSTOM_DNS_EXIST_IN_VAULT}" == "true" ]];then
          ./medusa export "${VAULT_CUSTOM_DNS_PATH}/${REGISTRY_NAME}" -o "${VAULT_CUSTOM_DNS_DATA_FILE}"
        fi
        unset VAULT_TOKEN && unset VAULT_ADDR
}

function import_registry_configuration_secrets() {
    export VAULT_ADDR=https://$(oc get routes -n ${USER_MANAGEMENT_NAMESPACE} ${VAULT_UM_ROUTE_NAME} \
                                 -o jsonpath='{.spec.host}')
    check_connection "${VAULT_ADDR}"
    export VAULT_TOKEN=$(oc get secret -n ${USER_MANAGEMENT_NAMESPACE} ${VAULT_UM_SECRET_NAME} \
                         -o jsonpath='{.data.VAULT_ROOT_TOKEN}' | base64 -d)
    if [[ "${IS_REGISTRY_KV_EXIST_IN_VAULT}" == "true" ]];then
    ./medusa import  "${VAULT_REGISTRY_DATA_PATH}" "${VAULT_REGISTRY_DATA_FILE}"
    fi
    if [[ "${IS_PLATFORM_INTEGRATION_EXIST_IN_VAULT}" == "true" ]];then
    ./medusa import  "${VAULT_PLATFORM_INTEGRATION_DATA_PATH}" "${VAULT_PLATFORM_INTEGRATION_DATA_FILE}"
    fi
    if [[ "${IS_CUSTOM_DNS_EXIST_IN_VAULT}" == "true" ]];then
    ./medusa import  "${VAULT_CUSTOM_DNS_PATH}" "${VAULT_CUSTOM_DNS_DATA_FILE}"
    fi
    unset VAULT_TOKEN && unset VAULT_ADDR
}

function create_registry_keycloak_client() {
    local keycloak_client_name
    keycloak_client_name="${REGISTRY_NAME}-admin"
    if ! oc get KeycloakClient -n "${USER_MANAGEMENT_NAMESPACE}" "${keycloak_client_name}" &> /dev/null;then
       oc apply -f - <<EOF
apiVersion: v1.edp.epam.com/v1
kind: KeycloakClient
metadata:
  name: ${keycloak_client_name}
  namespace: ${USER_MANAGEMENT_NAMESPACE}
  labels:
    relatedNamespace: ${REGISTRY_NAME}
spec:
  clientId: ${REGISTRY_NAME}-admin
  public: false
  directAccess: false
  reconciliationStrategy: addOnly
  advancedProtocolMappers: false
  serviceAccount:
    attributes: null
    clientRoles:
      - clientId: openshift-realm
        roles:
          - manage-clients
      - clientId: id-gov-ua-realm
        roles:
          - manage-clients
    enabled: true
    realmRoles:
      - create-realm
  webUrl: ''
  targetRealm: master
EOF
  else
    echo "[INFO] KeycloakClient ${keycloak_client_name} exit in namespace ${USER_MANAGEMENT_NAMESPACE}"
  fi
}

function modify_keycloak_secret() {
    local secret_name
    secret_name=keycloak-client-${REGISTRY_NAME}-admin-secret
    while [[ ! $(oc get secret -n ${USER_MANAGEMENT_NAMESPACE} "${secret_name}"  --ignore-not-found) ]];do
      echo "[INFO] Waiting for secret ${secret_name}"
      sleep 5
    done
    keycloakSecret=$(oc get secret -n ${USER_MANAGEMENT_NAMESPACE} "${secret_name}" -o jsonpath="{.data.clientSecret}")
    modify_resource "resources/secrets/namespaces/${REGISTRY_NAME}/keycloak.json" \
                    's/password":".*","user/password":"'${keycloakSecret}'","user/g'
}
function migrate_backup() {
    local target_unzip_dir_path archive_name crunchy_s3_conf_data nexus_namespaced_secret_data
    archive_name="${BACKUP_NAME}.tar.gz"
    crunchy_s3_conf_data=$(printf "[global]\nrepo1-s3-key=minio\nrepo1-s3-key-secret=%s" "${MINIO_DEST_SECRET_ACCESS_KEY}" | base64 -w0)
    nexus_namespaced_secret_data=$(echo "${SRC_NAMESPACED_DOCKERCONFIG_RAW}" | \
                                   sed 's/'${SRC_CLUSTER_DNS_WILDCARD}'/'${DEST_CLUSTER_DNS_WILDCARD}'/g' | base64 -w0)
    mkdir -p "${BACKUP_DIR_PATH}"
    pushd "${BACKUP_DIR_PATH}" || exit
      rclone --config "${RCLONE_CONFIG}" copy "${MINIO_SRC_NAME}:${MINIO_SRC_BUCKET_NAME}/openshift-backups/backups/${BACKUP_NAME}" "${BACKUP_NAME}"
      pushd "${BACKUP_NAME}" || exit
        target_unzip_dir_path="unzip"
        modify_resource "openshift-resources/postgrescluster/analytical.yaml" \
                        's/'${MINIO_SRC_BUCKET_NAME}'/'${MINIO_DEST_BUCKET_NAME}'/g'
        modify_resource "openshift-resources/postgrescluster/operational.yaml" \
                        's/'${MINIO_SRC_BUCKET_NAME}'/'${MINIO_DEST_BUCKET_NAME}'/g'
        change_dns_wildcard_in_resources "openshift-resources"
        mkdir -p "${target_unzip_dir_path}"
        tar -xf "${archive_name}" -C "${target_unzip_dir_path}"
        rm -rf "${archive_name}"
        pushd "${target_unzip_dir_path}" || exit
          change_dns_wildcard_in_resources "resources"
          modify_resource "resources/configmaps/namespaces/${REGISTRY_NAME}/hashicorp-vault-config.json" \
                          's/'${VAULT_SRC_PLATFORM_URL}'/'${VAULT_DEST_PLATFORM_REPL_ENDPOINT}'/g'
          modify_resource "resources/configmaps/namespaces/${REGISTRY_NAME}/hashicorp-vault-config.json" \
                           's/'${VAULT_SRC_KEY_NAME}'/'${VAULT_DEST_KEY_NAME}'/g'
          modify_resource "resources/secrets/namespaces/${REGISTRY_NAME}/central-vault-token.json" \
                          's/token":".*"},"kind/token":"'${VAULT_DEST_UM_TOKEN}'"},"kind/g'
          modify_resource "resources/secrets/namespaces/${REGISTRY_NAME}/platform-vault-token.json" \
                          's/token":".*"},"kind/token":"'${VAULT_DEST_PLATFORM_TOKEN}'"},"kind/g'
          modify_resource "resources/secrets/namespaces/${REGISTRY_NAME}/s3-conf.json" \
                          's/s3.conf":".*"},"kind/s3.conf":"'${crunchy_s3_conf_data}'"},"kind/g'
          modify_resource "resources/secrets/namespaces/${REGISTRY_NAME}/${NEXUS_NAMESPACED_SECRET}.json" \
                           's/dockerconfigjson":".*"},"kind/dockerconfigjson":"'${nexus_namespaced_secret_data}'"},"kind/g'
          modify_keycloak_secret

          for configmapPatern in "registry-kafka-api-master" "registry-soap-api-master" "registry-rest-api-master" "registry-model-master";do
            rm -rf resources/configmaps/namespaces/${REGISTRY_NAME}/${configmapPatern}*
          done
        popd || exit
        tar -zcf "${archive_name}" -C "${target_unzip_dir_path}" .
        rm -rf "${target_unzip_dir_path}"
      popd || exit
      rclone --config "${RCLONE_CONFIG}" copy "${BACKUP_NAME}" \
                      "${MINIO_DEST_NAME}:${MINIO_DEST_BUCKET_NAME}/openshift-backups/backups/${BACKUP_NAME}" \
                      --progress
    popd || exit
    rclone --config "${RCLONE_CONFIG}" sync \
                  "${MINIO_SRC_NAME}:${MINIO_SRC_BUCKET_NAME}/openshift-backups/restic/${REGISTRY_NAME}" \
                  "${MINIO_DEST_NAME}:${MINIO_DEST_BUCKET_NAME}/openshift-backups/restic/${REGISTRY_NAME}" \
                  --progress \
                  --transfers=16 \
                  --checkers=32 \
                  --buffer-size=32Mi
}

function export_from_src() {
    local src_platform_vault_url
    eval "${SRC_CLUSTER_LOGIN}"
    src_platform_vault_url=$(get_secret_attribute "${PLATFORM_VAULT_SETTINGS_SECRET}" "${CONTROL_PLANE_NAMESPACE}" ".data.vaultUrl")

    VAULT_SRC_PLATFORM_URL="${src_platform_vault_url/\/\//\\/\\/}"
    MINIO_SRC_BUCKET_NAME=$(get_secret_attribute "${MINIO_SETTINGS_SECRET}" "${CONTROL_PLANE_NAMESPACE}" ".data.backup-s3-like-storage-location")
    MINIO_SRC_ENDPOINT="$(get_secret_attribute "${MINIO_SETTINGS_SECRET}" "${CONTROL_PLANE_NAMESPACE}" \
                                                ".data.backup-s3-like-storage-url")" #check usage
    MINIO_SRC_ACCESS_KEY_ID=$(get_secret_attribute "${MINIO_SETTINGS_SECRET}" "${CONTROL_PLANE_NAMESPACE}" \
                                   '.data.backup-s3-like-storage-access-key-id')
    MINIO_SRC_SECRET_ACCESS_KEY=$(get_secret_attribute "${MINIO_SETTINGS_SECRET}" "${CONTROL_PLANE_NAMESPACE}" \
                                   '.data.backup-s3-like-storage-secret-access-key')
    SRC_NAMESPACED_DOCKERCONFIG_RAW=$(oc get secret -n "${REGISTRY_NAME}" ${NEXUS_NAMESPACED_SECRET} -o jsonpath='{.data.\.dockerconfigjson}' | base64 -d )
    SRC_CLUSTER_DNS_WILDCARD=$(get_dns_wildcard)

    if [ -z "${MIGRATE_BUCKETS_ONLY}" ];then
      configure_rclone_for_cluster "${MINIO_SRC_NAME}"
      export_vault_autounseal_key
      export_registry_configuration_secrets
      export_keycloak_realms
    fi

}

function import_to_dest() {
    local platform_vault_url platform_minio_url
    eval "${DEST_CLUSTER_LOGIN}"
    configure_rclone_for_cluster "${MINIO_DEST_NAME}"
    DEST_CLUSTER_DNS_WILDCARD=$(get_dns_wildcard)

    platform_vault_url=$(get_secret_attribute "${PLATFORM_VAULT_SETTINGS_SECRET}" "${CONTROL_PLANE_NAMESPACE}" \
                         ".data.vaultUrl")
    platform_minio_url=$(get_secret_attribute "${MINIO_SETTINGS_SECRET}" "${CONTROL_PLANE_NAMESPACE}" \
                        ".data.backup-s3-like-storage-url")


    MINIO_DEST_BUCKET_NAME=$(get_secret_attribute "${MINIO_SETTINGS_SECRET}" "${CONTROL_PLANE_NAMESPACE}" \
                             '.data.backup-s3-like-storage-location')
    MINIO_DEST_ENDPOINT="${platform_minio_url}" #check usage
    MINIO_DEST_ACCESS_KEY_ID=$(get_secret_attribute "${MINIO_SETTINGS_SECRET}" "${CONTROL_PLANE_NAMESPACE}" \
                               '.data.backup-s3-like-storage-access-key-id')
    MINIO_DEST_SECRET_ACCESS_KEY=$(get_secret_attribute "${MINIO_SETTINGS_SECRET}" "${CONTROL_PLANE_NAMESPACE}" \
                               '.data.backup-s3-like-storage-secret-access-key')
    VAULT_DEST_PLATFORM_TOKEN=$(get_secret_attribute "${PLATFORM_VAULT_SETTINGS_SECRET}" "${CONTROL_PLANE_NAMESPACE}" \
                                ".data.vault-access-token" | base64 -w0 )
    VAULT_DEST_PLATFORM_REPL_ENDPOINT="${platform_vault_url/\/\//\\/\\/}"
    VAULT_DEST_UM_TOKEN=$(get_secret_attribute "${VAULT_UM_SECRET_NAME}" "${USER_MANAGEMENT_NAMESPACE}" ".data.VAULT_ROOT_TOKEN" | base64 -w0)

    if [ -z "${MIGRATE_BUCKETS_ONLY}" ];then
      import_vault_autounseal_key
      import_registry_configuration_secrets
      create_registry_keycloak_client
      migrate_backup
    fi

}

function deploy_migration_job() {
    local local_values_file release_name src_minio_endpoint dest_minio_endpoint
    [ -n "${MINIO_SRC_ENDPOINT_OVERWRITE}" ] && src_minio_endpoint="${MINIO_SRC_ENDPOINT_OVERWRITE}" || src_minio_endpoint="${MINIO_SRC_ENDPOINT}"
    [ -n "${MINIO_DEST_ENDPOINT_OVERWRITE}" ] && dest_minio_endpoint="${MINIO_DEST_ENDPOINT_OVERWRITE}" || dest_minio_endpoint="${MINIO_DEST_ENDPOINT}"
    release_name="buckets-${REGISTRY_NAME}"
    helm_archive="buckets-migration-0.1.0.tgz"
    local_values_file="migration-${REGISTRY_NAME}.yaml"
    release_namespace="velero"
    cat <<EOF > "${local_values_file}"
global:
 registryName: "${REGISTRY_NAME}"
minio:
  src:
    url: ${src_minio_endpoint}
    accessKeyId: "${MINIO_SRC_ACCESS_KEY_ID}"
    secretAccessKey: "${MINIO_SRC_SECRET_ACCESS_KEY}"
    bucketName: "${MINIO_SRC_BUCKET_NAME}"
    sse: "${MINIO_SRC_SSE}"
  dest:
    url: ${dest_minio_endpoint}
    accessKeyId: "${MINIO_DEST_ACCESS_KEY_ID}"
    secretAccessKey: "${MINIO_DEST_SECRET_ACCESS_KEY}"
    bucketName: "${MINIO_DEST_BUCKET_NAME}"
    sse: "${MINIO_DEST_SSE}
EOF

    if helm list -n "${release_namespace}" | grep -q "${release_name}"; then
      echo "Release '${release_name}' exists in namespace '${release_namespace}'. Deleting it now..."
      helm uninstall "${release_name}" -n "${release_namespace}"
      if [[ $? -eq 0 ]]; then
        echo "Release '${release_name}' successfully deleted."
      else
        echo "Failed to delete release '${release_name}'."
        exit 1
      fi
    else
      echo "Release '${release_name}' does not exist in namespace '${release_namespace}'."
    fi
    helm upgrade --install -n "${release_namespace}" "${release_name}" --values "${local_values_file}" "${helm_archive}"
    if [[ $? -eq 0 ]]; then
     echo "[INFO] Please wait for the Jobs in the 'velero' namespace to complete before proceeding."
    else
     echo "[ERROR] Connectivity between cluster not stable."
     exit 1
    fi
   rm -rf "${local_values_file}"
}

function run_migration() {
  prerequisites
  export_from_src
  import_to_dest
  if [ -z "${BUCKET_MIGRATION}" ];then
    deploy_migration_job
  fi
  cleanup
}

run_migration "${@}"
