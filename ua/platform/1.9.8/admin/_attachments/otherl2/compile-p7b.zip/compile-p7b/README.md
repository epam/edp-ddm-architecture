# Certificate Conversion Script

A bash script to convert `.cer` files to `.pem` files and bundle them into a single `.p7b` file

## Table of Contents

- [About](#about)
- [Prerequisites](#prerequisites)
- [Usage](#usage)

## About <a name = "about"></a>

This script takes `.cer` files from the `.cer` directory, converts them to `.pem` format, and outputs them to a `.pem` directory. It then bundles all the resulting `.pem` files into a single `CACertificates.p7b` file before cleaning up the `.pem` directory.

## Prerequisites <a name = "prerequisites"></a>

- A Unix-like environment with `bash`.
- `openssl` (version 3.1.4 24 Oct 2023).
- `.cer` files must be placed in the `.cer` directory where the script is run.

> **Note:** Please ensure your `openssl` version supports the exact syntax and parameters used in the script. Older versions of `openssl` may work, but they were not tested.

## Usage <a name = "usage"></a>

In your terminal, navigate to the directory containing the script and run:

```bash
./main.sh
