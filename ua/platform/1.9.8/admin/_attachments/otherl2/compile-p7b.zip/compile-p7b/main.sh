#!/bin/bash
set -e
# Remove the "pem" directory and its files before execution.
rm -rf .pem
# If the ".pem" directory does not exist, create it.
if [ ! -d ".pem" ]; then
    mkdir .pem
fi

# Loop through all .cer files, convert and output them in "pem" directory.
for file in .cer/*.cer; do
    base_name=${file##*/}
    base_name=${base_name%.cer}
    openssl x509 -inform der -in "${file}" -out ".pem/${base_name}.pem"
done

# Initialize command variable.
cmd="openssl crl2pkcs7 -outform DER -nocrl"

# Loop through pem files and add them to the command variable.
for file in .pem/*.pem; do
    cmd+=" -certfile ${file}"
done

# Finalize command and output the result in CACertificates.p7b.
cmd+=" -out CACertificates.p7b"
eval "${cmd}"

# Remove the "pem" directory and its files after execution.
rm -rf .pem